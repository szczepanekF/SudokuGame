package pl.first.firstjava;


public class SudokuBox extends SudokuElement{
}
