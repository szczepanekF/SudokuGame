package pl.first.firstjava;



public class App {

    public static void main(final String[] args) {
        System.out.println(args[0]);
    }
}
