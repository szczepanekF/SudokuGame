package pl.first.firstjava;

public class SudokuColumn extends SudokuElement{
}
