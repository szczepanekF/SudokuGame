package pl.first.firstjava;

public class SudokuRow extends SudokuElement{
}
