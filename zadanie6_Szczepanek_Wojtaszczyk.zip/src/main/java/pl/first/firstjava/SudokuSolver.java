package pl.first.firstjava;

public interface SudokuSolver {

    void solve(SudokuBoard board);

}
